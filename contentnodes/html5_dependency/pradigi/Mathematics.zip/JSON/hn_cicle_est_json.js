﻿var gametext = [
	{
	    gmtry: "क्षेत्रफल लिखें-वृत्त",
	    gmtitle: "",
	    line2: "उंचाई",
		line3: "लंबाई",
		line4: "स्क्वायर लंबाई = ",
		line1: "= लाइन ²",			
		line5: "स्क्वायर क्षेत्रफल",		
		line6: "सेंमी.",
		line7: "गुण",
		btnplayagain1: "फिर से खेलें",
		txtunit:"1 एकक = ",
		line10: "समय",
		line8: "वृत्त का क्षेत्रफल",
		line9: "= π X r²",
		btnHelp: "पर्याय चुने",		
		solution: "जवाब",
		home: "शुरुवात",
		NextLevel: "अगला स्तर",
		btnNext: "अगला",
		btnok: "हो गया",
		totMark: "आपके गुण = ",
		useranstext: "आपका जवाब = ",
        correct: " यह जवाब सही है|"
}
]
