﻿var gametext = [
	{
	    gmtry: "क्षेत्रफळ सांगा-चौरस (पायरी ३)",
	    gmtitle: "",
	    line2: "उंची",
	    line3: "लांबी",
	    line6: "सेंमी.",
	    line10: "वेळ",
	    line7: "गुण",
	    line8: "क्षेत्रफळ",
	    line9: "= उंची X लांबी",
		btnplayagain1: "पुन्हा खेळा",
		txtunit:"1 एकक = ",
	    solution: "उत्तर",
		btnHelp: "पर्याय निवडा",	
	    home: "सुरुवात",
	    NextLevel: "मागील पायरी",
	    btnNext: "पुढे",
	    btnok: "उत्तर तपासा",
	    totMark: "आपले गुण = ",
	    useranstext: "तुमचे उत्तर = ",
	    correct: " हे उत्तर बरोबर आहे."
	}
]
