﻿var gametext = [
	{
	    gmtry: "अंदाजपंचे कोन (पायरी २)",
	    line1: "अंश",
	    btnok: "उत्तर तपासा",
	    line3: "लघुकोन",
	    line4: "काटकोन",
	    line5: "विशालकोन",
	    line6: "सरळकोन",
	    line7: "प्रतिक्षेपकोन",
	    line8: "शून्यकोन",
	    line9: "कोन हा 360° पेक्षा मोठा असू नये.",
		btnplayagain1: "पुन्हा खेळा",
	    home: "सुरुवात",
	    NextLevel: "मागील पायरी",
		btnHelp: "पर्याय निवडा",	
	    btnNext: "पुढे",
	    totMark: "आपले गुण = ",
	    line10: "वेळ",
	    line2: "गुण",
	    useranstext: "तुमचे उत्तर = ",
	    correct: " हे उत्तर बरोबर आहे."
	}
]
