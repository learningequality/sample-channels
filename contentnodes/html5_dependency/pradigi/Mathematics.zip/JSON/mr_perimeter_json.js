﻿var gametext = [
	{
	    gmtry: "हे करून पहा",
	    gmred: "",
	    gmtitle: "चौरसाची लांबी बदलून बघा.",
	    line1: "लांबी आणि उंची टाका",
	    line2: "उंची",
	    line3: "लांबी",
	    btnsubmit: "बघा",
	    line5: "परिमिती",
	    line6: "सेंमी"
	}
]