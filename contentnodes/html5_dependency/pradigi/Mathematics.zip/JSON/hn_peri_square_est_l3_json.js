﻿var gametext = [
	{
	    gmtry: "परिमाप लिखें-वर्ग (स्तर ३)",
	    gmtitle: "",
	    line2: "उंचाई",
	    line3: "लंबाई",
	    line6: "सेंमी.",
	    line7: "गुण",
	    line10: "समय",
	    line8: "परिमाप",
		btnplayagain1: "फिर से खेलें",
		line9: "= 4 X उंचाई (और लंबाई)",
		txtunit:"1 एकक = ",
	    solution: "जवाब",
		btnHelp: "पर्याय चुने",	
	    home: "शुरुवात",
	    NextLevel: "अगला स्तर",
	    btnNext: "अगला",
	    btnok: "हो गया",
	    totMark: "आपके गुण = ",
	    useranstext: "आपका जवाब = ",
	    correct: " यह जवाब सही है|"
	}
]
