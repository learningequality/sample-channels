﻿var gametext = [
	{
	    gmtry: "कोशिश करें",
	    gmtitle: "लाल डॉट को खींचकर नीचे मार्कर समायोजित करें|",
	    line1: "वृद्धि",
	    line2: "से.मी.",
	    line3: "कटौती",
	    line4: "से.मी.",
		line5: "AB = AC + BC",
		line6: "BC = AB - AC"
	}
]