﻿var gametext = [
	{
	    gmtry: "हे करून पहा",
	    gmred: "लाल ",
	    gmtitle: "ठिपके हलवून वर्तुळाची त्रिज्या बदला.",
	    line1: "त्रिज्या (R)=",
	    btnsubmit: "बघा",
	    line3: "क्षेत्रफळ",
	    line4: "परीघ",
	    line5: "व्यास",
	    line6: "सेंमी"
	}
]