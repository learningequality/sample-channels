﻿var gametext = [
	{
	    gmtry: "क्षेत्रफल लिखें-आयत (स्तर २)",
	    gmtitle: "",
	    line2: "ऊंचाई",
	    line3: "लम्बाई",
	    line6: "सेंमी.",
	    line7: "गुण",
	    line10: "समय",
		btnplayagain1: "फिर से खेलें",
	    line8: "क्षेत्रफल",
	    line9: "= लम्बाई X ऊंचाई ",
	    solution: "हल",
		txtunit:"1 एकक = ",
	    home: "पिछला स्तर",
	    NextLevel: "अगला स्तर",
		btnHelp: "पर्याय चुने",		
	    btnNext: "अगला",
	    btnok: "हो गया",
	    totMark: "आपके गुण = ",
	    useranstext: "आपका जवाब = ",
	    correct: " यह जवाब सही है|"
	}
]
