﻿var gametext = [
	{
	    gmtry: "क्षेत्रफल लिखें-त्रिभुज (स्तर 1)",
	    gmred: "",
	    gmtitle: "",
		solution: "उत्तर",
		line1:"= ½ X तल X ऊंचाई",
		line2:"= ½ X BC X AD",
		home: "शुरुवात",
		btnplayagain1: "फिर से खेलें",
		btnHelp: "पर्याय चुने",
		NextLevel: "अगला स्तर",
		tribase:"तल = ",
		triheight:"ऊंचाई = ",
		btnNext: "अगला",
		btnok: "हो गया",
		totMark: "आपके गुण = ",
		totMark1: "गुण",
		line10: "समय",
		useranstext: "आपका जवाब = ",
        correct: " यह जवाब सही है|"
	}
]
