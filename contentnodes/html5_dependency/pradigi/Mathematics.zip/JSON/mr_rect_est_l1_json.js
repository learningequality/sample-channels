﻿var gametext = [
	{
	    gmtry: "क्षेत्रफळ सांगा-चौरस (पायरी १)",
	    gmtitle: "",
	    line2: "उंची",
		line3: "लांबी",
		line6: "सेंमी.",
		line10: "वेळ",
		line7: "गुण",
		line8: "क्षेत्रफळ",
		btnplayagain1: "पुन्हा खेळा",
		txtunit:"1 एकक = ",
		line9: "= उंची X लांबी",
		btnHelp: "पर्याय निवडा",		
		solution: "उत्तर",
		home: "सुरुवात",
		NextLevel: "पुढील पायरी",
		btnNext: "पुढे",
		btnok: "उत्तर तपासा",
		totMark: "आपले गुण = ",
		useranstext: "तुमचे उत्तर = ",
        correct: " हे उत्तर बरोबर आहे."
}
]
