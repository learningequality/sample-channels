﻿var gametext = [
	{
	    gmtry: "क्षेत्रफळ सांगा-त्रिकोण (पायरी 3)",
	    gmred: "",
	    gmtitle: "",
		solution: "उत्तर",
		line1:"= ½ X पाया X उंची",
		line2:"= ½ X BC X AD",
		btnplayagain1: "पुन्हा खेळा",
		home: "सुरुवात",
		btnHelp: "पर्याय निवडा",
		NextLevel: "मागील पायरी",
		btnNext: "पुढे",
		tribase:"पाया = ",
		triheight:"उंची = ",
		btnok: "उत्तर तपासा",
		totMark: "आपले गुण = ",
		totMark1: "गुण",
		line10: "वेळ",
		useranstext: "तुमचे उत्तर = ",
        correct: " हे उत्तर बरोबर आहे."
	}
]
