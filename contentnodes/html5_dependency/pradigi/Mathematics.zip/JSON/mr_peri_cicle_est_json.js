﻿var gametext = [
	{
	    gmtry: "परिमिती सांगा-वर्तुळ",
	    gmtitle: "",
	    line2: "उंची",
		line3: "लांबी",
		line4: "चौरसाची बाजू = ",
		line1: "= 4 X बाजू",			
		line5: "चौरसाची परिमिती",		
		btnplayagain1: "पुन्हा खेळा",
		line6: "सेंमी.",
		txtunit:"1 एकक = ",
		line10: "वेळ",
		line7: "गुण",
		line8: "वर्तुळाची परिमिती",
		line9: "= 2 X π X r",
		btnHelp: "पर्याय निवडा",		
		solution: "उत्तर",
		home: "सुरुवात",
		NextLevel: "पुढील पायरी",
		btnNext: "पुढे",
		btnok: "उत्तर तपासा",
		totMark: "आपले गुण = ",
		useranstext: "तुमचे उत्तर = ",
        correct: " हे उत्तर बरोबर आहे."
}
]
