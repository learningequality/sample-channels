﻿var gametext = [
	{
	    gmtry: "क्षेत्रफल लिखें-वर्ग (स्तर २)",
	    gmtitle: "",
	    line2: "उंचाई",
	    line3: "लंबाई",
	    line6: "सेंमी.",
	    line7: "गुण",
	    line10: "समय",
	    line8: "क्षेत्रफल",
		btnplayagain1: "फिर से खेलें",
		txtunit:"1 एकक = ",
	    line9: "= उंचाई X लंबाई",
	    solution: "जवाब",
		btnHelp: "पर्याय चुने",	
	    home: "पिछला स्तर",
	    NextLevel: "अगला स्तर",
	    btnNext: "अगला",
	    btnok: "हो गया",
	    totMark: "आपके गुण = ",
	    useranstext: "आपका जवाब = ",
	    correct: " यह जवाब सही है|"
	}
]
