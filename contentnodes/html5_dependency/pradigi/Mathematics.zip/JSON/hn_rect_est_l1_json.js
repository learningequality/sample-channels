﻿var gametext = [
	{
	    gmtry: "क्षेत्रफल लिखें-वर्ग (स्तर १)",
	    gmtitle: "",
	    line2: "उंचाई",
		line3: "लंबाई",
		line6: "सेंमी.",
		line7: "गुण",
		line10: "समय",
		btnplayagain1: "फिर से खेलें",
		txtunit:"1 एकक = ",
		line8: "क्षेत्रफल",
		line9: "= उंचाई X लंबाई",
		btnHelp: "पर्याय चुने",		
		solution: "जवाब",
		home: "शुरुवात",
		NextLevel: "अगला स्तर",
		btnNext: "अगला",
		btnok: "हो गया",
		totMark: "आपके गुण = ",
		useranstext: "आपका जवाब = ",
        correct: " यह जवाब सही है|"
}
]
