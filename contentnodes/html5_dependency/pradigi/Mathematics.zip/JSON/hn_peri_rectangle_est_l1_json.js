﻿var gametext = [
	{
	    gmtry: "परिमाप लिखें-आयत (स्तर १)",
	    gmtitle: "",
	    line2: "ऊंचाई",
	    line3: "लम्बाई",
	    line6: "सेंमी.",
	    line8: "परिमाप",
	    line9: "= 2 ( लम्बाई + ऊंचाई )",
	    line7: "गुण",
	    line10: "समय",
		btnplayagain1: "फिर से खेलें",
		txtunit:"1 एकक = ",
	    solution: "हल",
	    home: "शुरुवात",
	    NextLevel: "अगला स्तर",
		btnHelp: "पर्याय चुने",		
	    btnNext: "अगला",
	    btnok: "हो गया",
	    totMark: "आपके गुण = ",
	    useranstext: "आपका जवाब = ",
	    correct: " यह जवाब सही है|"
	}
]
