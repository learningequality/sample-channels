﻿var gametext = [
	{
	    gmtry: "हे करून पहा",
	    gmtitle: "लाल बिंदू ओढून खालील मार्कर समायोजित करा.",
	    line1:"बेरीज",
	    line2:"सेंमी.",
	    line3:"वजाबाकी",
	    line4: "सेंमी.",
		line5: "AB = AC + BC",
		line6: "BC = AB - AC"
	}
]