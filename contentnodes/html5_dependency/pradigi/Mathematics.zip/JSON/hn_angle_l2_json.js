﻿var gametext = [
	{
	    gmtry: "तुक्काबाजी - कोण (स्तर २)",
	    line1: "डिग्री",
	    btnok: "हो गया",
	    line3: "न्यूनकोण",
	    line4: "समकोण",
	    line5: "अधिककोण",
	    line6: "ऋजुकोण",
	    line7: "प्रतिक्षेपकोण",
	    line8: "शून्यकोण",
		btnplayagain1: "फिर से खेलें",
	    line9: "कोण 360° से अधिकतम नहीं होना चाहिए|",
	    home: "शुरुवात",
	    NextLevel: "पिछला स्तर",
		btnHelp: "पर्याय चुने",		
	    btnNext: "अगला",
	    totMark: "आपके गुण = ",
	    line2: "गुण",
	    line10: "समय",
	    useranstext: "आपका जवाब = ",
	    correct: " यह जवाब सही है|"
	}
]
