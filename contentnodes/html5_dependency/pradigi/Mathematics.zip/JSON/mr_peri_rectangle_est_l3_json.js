﻿var gametext = [
	{
	    gmtry: "परिमिती सांगा-आयत (पायरी ३)",
	    gmtitle: "",
	    line2: "उंची",
	    line3: "लांबी",
	    line6: "सेंमी.",
	    line10: "वेळ",
	    line7: "गुण",
	    line8: "परिमिती",
		btnplayagain1: "पुन्हा खेळा",
	    line9: "= 2 ( लांबी + उंची )",
		txtunit:"1 एकक = ",
	    solution: "उत्तर",
	    home: "सुरुवात",
	    NextLevel: "मागील पायरी",
		btnHelp: "पर्याय निवडा",	
	    btnNext: "पुढे",
	    btnok: "उत्तर तपासा",
	    totMark: "आपले गुण = ",
	    useranstext: "तुमचे उत्तर = ",
	    correct: " हे उत्तर बरोबर आहे."
	}
]
