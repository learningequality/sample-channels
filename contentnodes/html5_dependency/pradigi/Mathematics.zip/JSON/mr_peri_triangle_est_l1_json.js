﻿var gametext = [
	{
	    gmtry: "परिमिती सांगा-त्रिकोण (पायरी 1)",
	    gmred: "",
	    gmtitle: "",
		solution: "उत्तर",
		line1:"= AB + BC + AC",
		btnplayagain1: "पुन्हा खेळा",
		home: "सुरुवात",
		btnHelp: "पर्याय निवडा",
		NextLevel: "पुढील पायरी",
		btnNext: "पुढे",
		tribase:"पाया = ",
		triheight:"उंची = ",
		btnok: "उत्तर तपासा",
		totMark: "आपले गुण = ",
		totMark1: "गुण",
		line10: "वेळ",
		useranstext: "तुमचे उत्तर = ",
        correct: " हे उत्तर बरोबर आहे."
	}
]
