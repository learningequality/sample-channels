﻿
//public int autoid { get; set; }
//public string userid { get; set; }
//public string resid { get; set; }
//public Nullable<System.DateTime> startdate { get; set; }
//public Nullable<System.DateTime> enddate { get; set; }
//public string status { get; set; }


//public int autoint { get; set; }
//public string userid { get; set; }
//public string resid { get; set; }
//public string reslevel { get; set; }
//public string questiontext { get; set; }
//public string correctans { get; set; }
//public string userans { get; set; }
//public string flag { get; set; }
//public string points { get; set; }
//public Nullable<System.DateTime> datetime { get; set; }
//public string status { get; set; }

var village = {};
village.VillageId = "1";
village.VillageCode = "1";
village.VillageName = "2";
village.Block = "4";
village.District = "4";
village.State = "6";
village.CRLId = "7";


var usrlog = {};
usrlog.autoid = 1;
usrlog.userid = "";
usrlog.resid = "";
usrlog.startdate = "";
usrlog.enddate = "";
usrlog.status = "";

var usrscore = {};
usrscore.autoint = 1;
usrscore.userid = "";
usrscore.resid = "";
usrscore.reslevel = "";
usrscore.questiontext = "";
usrscore.correctans = "";
usrscore.userans = "";
usrscore.flag = "";
usrscore.points = "";
usrscore.startdate = "";
usrscore.status = "";

var objscore = {};
objscore.autoid = 1;
objscore.PlayerId = "";
objscore.SessionId = GenerateGUID();
objscore.ResourceId = "1";
objscore.QuestionId = "1";
objscore.ScoredMarks = 0;
objscore.TotalMarks = 0;
objscore.StartDateTime = new Date();
objscore.EndDateTime = new Date();
objscore.Level = "1";

var gamepagedata = [
	{ game_id: "mr_area_est_l1", res_id: "RES01", level: "1" },
	{ game_id: "mr_area_est_l2", res_id: "RES02", level: "2" },
	{ game_id: "mr_area_est_l3", res_id: "RES03", level: "3" },
	{ game_id: "hn_area_est_l1", res_id: "RES04", level: "1" },
	{ game_id: "hn_area_est_l2", res_id: "RES05", level: "2" },
	{ game_id: "hn_area_est_l3", res_id: "RES06", level: "3" },
	{ game_id: "mr_rect_est_l1", res_id: "RES07", level: "1" },
	{ game_id: "mr_rect_est_l2", res_id: "RES08", level: "2" },
	{ game_id: "mr_rect_est_l3", res_id: "RES09", level: "3" },
	{ game_id: "hn_rect_est_l1", res_id: "RES10", level: "1" },
	{ game_id: "hn_rect_est_l2", res_id: "RES11", level: "2" },
	{ game_id: "hn_rect_est_l3", res_id: "RES12", level: "3" },
	{ game_id: "mr_triangle_est_l1", res_id: "RES13", level: "1" },
	{ game_id: "mr_triangle_est_l2", res_id: "RES14", level: "2" },
	{ game_id: "mr_triangle_est_l3", res_id: "RES15", level: "3" },
	{ game_id: "hn_triangle_est_l1", res_id: "RES16", level: "1" },
	{ game_id: "hn_triangle_est_l2", res_id: "RES17", level: "2" },
	{ game_id: "hn_triangle_est_l3", res_id: "RES18", level: "3" },
	{ game_id: "hn_angle_est_l1", res_id: "RES19", level: "1" },
	{ game_id: "hn_angle_est_l2", res_id: "RES20", level: "2" },
	{ game_id: "mr_angle_est_l1", res_id: "RES21", level: "1" },
	{ game_id: "mr_angle_est_l2", res_id: "RES22", level: "2" },
	{ game_id: "hn_circle_est", res_id: "RES23", level: "1" },
	{ game_id: "mr_circle_est", res_id: "RES24", level: "1" }
];

var DeviceType = "Mobile";

function GetFormatDate(dtdate) {
    return dtdate.getMonth() + "/" + dtdate.getDate() + "/" + dtdate.getFullYear() + " " + dtdate.getHours() + ":" + dtdate.getMinutes() + ":" + dtdate.getSeconds() + "." + dtdate.getMilliseconds();
}

function GenerateGUID() {
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
};


function getResInfo(resname) {
    var respos = gamepagedata.filter(function (el) {
        //console.log("id=" + el.game_id);
        return (el.game_id === resname);
    });
    return respos;
}

function fnAddScore(obj) {
    if (DeviceType == "Desktop") {
        var resoruceid = getResInfo(obj.resname)[0].res_id;
        var level = getResInfo(obj.resname)[0].level;

        objscore.autoid = 1;
        if (typeof $.cookie('userid') != "undefined")
            objscore.PlayerId = $.cookie('userid');
        else
            objscore.PlayerId = "Guest";

        objscore.SessionId = obj.sessionid;
        objscore.ResourceId = resoruceid;
        objscore.QuestionId = "0";
        objscore.ScoredMarks = obj.scoredmarks;
        objscore.TotalMarks = obj.totalmarks;
        objscore.StartDateTime = GetFormatDate(new Date());
        objscore.EndDateTime = GetFormatDate(new Date());
        objscore.Level = level;

        AddScore(objscore);
    }
    return true;
}




function AddScore(objscore) {
    $.ajax({
        url: "/api/Score/WsAddScore",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        data: JSON.stringify(objscore),
        dataType: "json",
        async: true,
        success: function (response) {
            //alert(response);
            return true;
        },
        error: function (x, e) {
            alert(x.responseText + x.status);
            return false;
        }
    });
}


function AddLogInfo(usrlog) {
    alert(usrlog);

    $.ajax({
        url: "/api/LmsLog/AddLmsLog",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        data: JSON.stringify(usrlog),
        //data: JSON.stringify({ 'usrlog': usrlog }),
        dataType: "json",
        success: function (response) {
            alert(response);
            return true;
            //getAllContacts();
        },
        error: function (x, e) {
            //alert('Failed');
            alert(x.responseText + x.status);
            return false;
        }
    });
}

function AddVillageInfo() {
    //alert(usrlog);
    var lstvillage = new Array();

    village = {};
    village.VillageId = "5";
    village.VillageCode = "1";
    village.VillageName = "2";
    village.Block = "4";
    village.District = "4";
    village.State = "6";
    village.CRLId = "7";

    lstvillage.push(village);

    village = {};
    village.VillageId = "6";
    village.VillageCode = "1";
    village.VillageName = "2";
    village.Block = "4";
    village.District = "4";
    village.State = "6";
    village.CRLId = "7";

    lstvillage.push(village);

    village = {};
    village.VillageId = "1";
    village.VillageCode = "1";
    village.VillageName = "2";
    village.Block = "4";
    village.District = "4";
    village.State = "6";
    village.CRLId = "7";

    lstvillage.push(village);

    

    //console.log(lstvillage);
    console.log(JSON.stringify(lstvillage));
    $.ajax({
        url: "/api/Village/WsAddVillageList",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        //data: '{"lstvillage":' + JSON.stringify(lstvillage) + '}',
        //data: { _Objects: JSON.stringify(lstvillage) },
        //data: JSON.stringify(lstvillage),
        //data: JSON.stringify({ 'lstvillage': lstvillage }),
        data: JSON.stringify(lstvillage),
        //data: JSON.stringify(lstvillage),
        dataType: "json",
        async: false,
        success: function (response) {
            alert(response);
            return true;
            //getAllContacts();
        },
        error: function (x, e) {
            //alert('Failed');
            alert(x.responseText + x.status);
            return false;
        }
    });
}


function AddLogScore(usrscore) {
    $.ajax({
        url: "/api/LmsScore/AddLmsScore",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        data: JSON.stringify(usrscore),
        //data: JSON.stringify({ 'usrlog': usrlog }),
        dataType: "json",
        async: false,
        success: function (response) {
            alert(response);
            return true;
            //getAllContacts();
        },
        error: function (x, e) {
            //alert('Failed');
            alert(x.responseText + x.status);
            return false;
        }
    });
}

//    var Emp = {};
//    Emp.FirstName = $("#<%=txtFirstName.ClientID %>").val();
//    Emp.LastName = $("#<%=txtLastName.ClientID %>").val();
//    Emp.PhoneNo = $("#<%=txtPhone.ClientID %>").val();
//    Emp.Company = $("#<%=txtCompany.ClientID %>").val();
//    Emp.Email = $("#<%=txtEmail.ClientID %>").val();
//    $.ajax({
//        url: "<%=Page.ResolveUrl("/api/User/AddUser")%>",
//        type: "POST",
//    contentType: "application/json;charset=utf-8",
//    data: JSON.stringify(Emp),
//    dataType: "json",
//    success: function (response) {
//        alert(response);
//        getAllContacts();
//    },
//    error: function (x, e) {
//        alert('Failed');
//        alert(x.responseText);
//        alert(x.status);
//    }
//});
