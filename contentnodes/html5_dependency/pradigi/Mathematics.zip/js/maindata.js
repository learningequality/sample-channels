﻿var jsondata = [
	{ game_id: "LES01", num_arr:"2", level_id: "1",  Arr_Range1: "1",  Arr_Range2: "5",  Arr_Range3: "10", Right_ans:"5"},
	{ game_id: "LES01", num_arr:"3", level_id: "1",  Arr_Range1: "5",  Arr_Range2: "10",  Arr_Range3: "15", Right_ans:"10"},
	{ game_id: "LES01", num_arr:"4", level_id: "1",  Arr_Range1: "10",  Arr_Range2: "20",  Arr_Range3: "30", Right_ans:"20"},
	{ game_id: "LES01", num_arr:"5", level_id: "1",  Arr_Range1: "10",  Arr_Range2: "20",  Arr_Range3: "30", Right_ans:"20"},
	{ game_id: "LES01", num_arr:"6", level_id: "1",  Arr_Range1: "20",  Arr_Range2: "40",  Arr_Range3: "60", Right_ans:"40"},
	{ game_id: "LES01", num_arr:"7", level_id: "1",  Arr_Range1: "30",  Arr_Range2: "50",  Arr_Range3: "70", Right_ans:"50"},
	{ game_id: "LES01", num_arr:"8", level_id: "1",  Arr_Range1: "30",  Arr_Range2: "60",  Arr_Range3: "90", Right_ans:"60"},
	{ game_id: "LES01", num_arr:"9", level_id: "1",  Arr_Range1: "40",  Arr_Range2: "80",  Arr_Range3: "120", Right_ans:"80"},
      
	{ game_id: "LES02", num_arr:"2", level_id: "2",  Arr_Range1: "2",  Arr_Range2: "4",  Arr_Range3: "6", Right_ans:"4"},
	{ game_id: "LES02", num_arr:"3", level_id: "2",  Arr_Range1: "12",  Arr_Range2: "9",  Arr_Range3: "6", Right_ans:"9"},
	{ game_id: "LES02", num_arr:"4", level_id: "2",  Arr_Range1: "16",  Arr_Range2: "8",  Arr_Range3: "12", Right_ans:"15"},
	{ game_id: "LES02", num_arr:"5", level_id: "2",  Arr_Range1: "20",  Arr_Range2: "25",  Arr_Range3: "30", Right_ans:"25"},
	{ game_id: "LES02", num_arr:"6", level_id: "2",  Arr_Range1: "30",  Arr_Range2: "36",  Arr_Range3: "42", Right_ans:"36"},
	{ game_id: "LES02", num_arr:"7", level_id: "2",  Arr_Range1: "42",  Arr_Range2: "49",  Arr_Range3: "35", Right_ans:"49"},
	{ game_id: "LES02", num_arr:"8", level_id: "2",  Arr_Range1: "60",  Arr_Range2: "65",  Arr_Range3: "70", Right_ans:"65"},
	{ game_id: "LES02", num_arr:"9", level_id: "2",  Arr_Range1: "75",  Arr_Range2: "80",  Arr_Range3: "85", Right_ans:"80"},
    
	{ game_id: "LES03", num_arr:"2", level_id: "3",  Arr_Range1: "3",  Arr_Range2: "4",  Arr_Range3: "5", Right_ans:"4"},
	{ game_id: "LES03", num_arr:"3", level_id: "3",  Arr_Range1: "8",  Arr_Range2: "9",  Arr_Range3: "10", Right_ans:"9"},
	{ game_id: "LES03", num_arr:"4", level_id: "3",  Arr_Range1: "15",  Arr_Range2: "16",  Arr_Range3: "17", Right_ans:"16"},
	{ game_id: "LES03", num_arr:"5", level_id: "3",  Arr_Range1: "24",  Arr_Range2: "25",  Arr_Range3: "26", Right_ans:"25"},
	{ game_id: "LES03", num_arr:"6", level_id: "3",  Arr_Range1: "35",  Arr_Range2: "36",  Arr_Range3: "37", Right_ans:"36"},
	{ game_id: "LES03", num_arr:"7", level_id: "3",  Arr_Range1: "48",  Arr_Range2: "49",  Arr_Range3: "50", Right_ans:"49"},
	{ game_id: "LES03", num_arr:"8", level_id: "3",  Arr_Range1: "63",  Arr_Range2: "64",  Arr_Range3: "65", Right_ans:"64"},
	{ game_id: "LES03", num_arr:"9", level_id: "3",  Arr_Range1: "80",  Arr_Range2: "81",  Arr_Range3: "82", Right_ans:"81"}

];