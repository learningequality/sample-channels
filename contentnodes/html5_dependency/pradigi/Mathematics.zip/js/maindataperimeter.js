﻿var jsondata = [
	{ game_id: "LES01", num_arr:"2", level_id: "1",  Arr_Range1: "1",  Arr_Range2: "5",  Arr_Range3: "10", Right_ans:"5"},
	{ game_id: "LES01", num_arr:"3", level_id: "1",  Arr_Range1: "5",  Arr_Range2: "10",  Arr_Range3: "15", Right_ans:"10"},
	{ game_id: "LES01", num_arr:"4", level_id: "1",  Arr_Range1: "10",  Arr_Range2: "15",  Arr_Range3: "20", Right_ans:"15"},
	{ game_id: "LES01", num_arr:"5", level_id: "1",  Arr_Range1: "15",  Arr_Range2: "20",  Arr_Range3: "25", Right_ans:"20"},
	{ game_id: "LES01", num_arr:"6", level_id: "1",  Arr_Range1: "20",  Arr_Range2: "25",  Arr_Range3: "30", Right_ans:"25"},
	{ game_id: "LES01", num_arr:"7", level_id: "1",  Arr_Range1: "25",  Arr_Range2: "30",  Arr_Range3: "35", Right_ans:"30"},
	{ game_id: "LES01", num_arr:"8", level_id: "1",  Arr_Range1: "25",  Arr_Range2: "30",  Arr_Range3: "35", Right_ans:"30"},
	{ game_id: "LES01", num_arr:"9", level_id: "1",  Arr_Range1: "30",  Arr_Range2: "35",  Arr_Range3: "40", Right_ans:"35"},
      
	{ game_id: "LES02", num_arr:"2", level_id: "2",  Arr_Range1: "4",  Arr_Range2: "8",  Arr_Range3: "12", Right_ans:"8"},
	{ game_id: "LES02", num_arr:"3", level_id: "2",  Arr_Range1: "8",  Arr_Range2: "12",  Arr_Range3: "16", Right_ans:"12"},
	{ game_id: "LES02", num_arr:"4", level_id: "2",  Arr_Range1: "12",  Arr_Range2: "16",  Arr_Range3: "20", Right_ans:"16"},
	{ game_id: "LES02", num_arr:"5", level_id: "2",  Arr_Range1: "16",  Arr_Range2: "20",  Arr_Range3: "24", Right_ans:"20"},
	{ game_id: "LES02", num_arr:"6", level_id: "2",  Arr_Range1: "20",  Arr_Range2: "24",  Arr_Range3: "28", Right_ans:"24"},
	{ game_id: "LES02", num_arr:"7", level_id: "2",  Arr_Range1: "24",  Arr_Range2: "28",  Arr_Range3: "32", Right_ans:"28"},
	{ game_id: "LES02", num_arr:"8", level_id: "2",  Arr_Range1: "28",  Arr_Range2: "32",  Arr_Range3: "36", Right_ans:"32"},
	{ game_id: "LES02", num_arr:"9", level_id: "2",  Arr_Range1: "32",  Arr_Range2: "36",  Arr_Range3: "40", Right_ans:"36"},
    
	{ game_id: "LES03", num_arr:"2", level_id: "3",  Arr_Range1: "6",  Arr_Range2: "8",  Arr_Range3: "7", Right_ans:"8"},
	{ game_id: "LES03", num_arr:"3", level_id: "3",  Arr_Range1: "10",  Arr_Range2: "12",  Arr_Range3: "8", Right_ans:"12"},
	{ game_id: "LES03", num_arr:"4", level_id: "3",  Arr_Range1: "14",  Arr_Range2: "16",  Arr_Range3: "18", Right_ans:"16"},
	{ game_id: "LES03", num_arr:"5", level_id: "3",  Arr_Range1: "18",  Arr_Range2: "20",  Arr_Range3: "19", Right_ans:"20"},
	{ game_id: "LES03", num_arr:"6", level_id: "3",  Arr_Range1: "22",  Arr_Range2: "24",  Arr_Range3: "26", Right_ans:"24"},
	{ game_id: "LES03", num_arr:"7", level_id: "3",  Arr_Range1: "26",  Arr_Range2: "28",  Arr_Range3: "24", Right_ans:"28"},
	{ game_id: "LES03", num_arr:"8", level_id: "3",  Arr_Range1: "30",  Arr_Range2: "32",  Arr_Range3: "34", Right_ans:"32"},
	{ game_id: "LES03", num_arr:"9", level_id: "3",  Arr_Range1: "32",  Arr_Range2: "36",  Arr_Range3: "34", Right_ans:"36"}

];