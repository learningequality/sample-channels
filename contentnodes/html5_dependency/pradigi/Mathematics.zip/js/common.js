﻿$(document).ready(function () {

    $("#ri").keyup(function (e) {
        var interest = parseFloat(this.value.replace(' % p.a', ''));
        if (interest > 99.99) {
            alert('Please enter interest rate between 0 to 99.99')
            this.value = ""
            return
        }
        if (interest < 0) return;
        if (isFloat(interest) || !isNaN(interest)) {
        } else {
            //alert('Please enter integer value')
            this.value = ""
            return
        }        
    });
});

$(document).ready(function () {

    $("#txtradius").keyup(function (e) {
        var interest = parseFloat(this.value.replace(' % p.a', ''));
        if (interest > 50) {
            alert('Please enter radius between 0 to 50')
            this.value = ""
            return
        }
        if (interest < 0) return;
        if (isFloat(interest) || !isNaN(interest)) {
        } else {
            //alert('Please enter integer value')
            this.value = ""
            return
        }
    });
});

function isFloat(value) {
    return value != "" && !isNaN(value) && Math.round(value) != value;
}

$(document).ready(function () {
    $("#txtboxToFilter").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
});
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    //console.log(charCode);
    if (charCode != 46 && charCode != 189 && charCode > 31
    && (charCode < 48 || charCode > 57))
        return false;

    return true;
}

function maxLengthCheck(object) {
    if (object.value.length > object.maxLength)
        object.value = object.value.slice(0, object.maxLength)
}

$(document).ready(function () {
    //$("#f").html("<input type=\"button\" id=\"clear\"  value=\"Clear\"/> <input type=\"button\" id=\"calculate\"  value=\"Calculate\"/>");
    
    $("#calculate").click(function () {
        var la = parseFloat($('#la').val());
        var ri = parseFloat($('#ri').val());
        var nm = parseFloat($('#nm').val());
        var r = ri / 1200;

        var emi = la * r * Math.pow(1 + r, nm) / (Math.pow(1 + r, nm) - 1);
        var tla = emi * nm;

        $('#mp').val(emi.toFixed(2));
        $('#tla').val(tla.toFixed(2));
        $('#ia').val((tla - la).toFixed(2));
    });
});
function GetMinVariation(qnum, per) {
    return (parseFloat(qnum) - ((parseFloat(per) / 100 * parseFloat(qnum))));
}

function GetMaxVariation(qnum, per) {
    return (parseFloat(qnum) + ((parseFloat(per) / 100 * parseFloat(qnum))));
}
function GetRandomNumber(mx, mn) {
    return parseInt((Math.random() * (mx - mn + 1)), 10) + mn;
}

function shuffle(o){
    for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}
function GenerateGUID() {
    var d = new Date().getTime();
    var guid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x3|0x8)).toString(16);
    });
    return guid;
};
