var TexthelpSpeechStream = new function (){};

//*** Example template for SpeechStream toolbar configuration with new UI.
//*** Areas below marked with //*** signify lines to change for customer specific set ups.

// Adding toolbar to the page
TexthelpSpeechStream.g_bAdded = false;
TexthelpSpeechStream.g_strServer = "commonlittoolbar.speechstream.net";     //*** Set to customer specific domain  (i.e. "customerxtoolbar.speechstream.net")
TexthelpSpeechStream.g_strSpeechServer = "commonlitservices.speechstream.net";
TexthelpSpeechStream.g_strSpeechServerBackup = "commonlitservicesbackup.speechstream.net";
TexthelpSpeechStream.g_strCacheServer = "s3-us-west-2.amazonaws.com/sscache.speechstream.net";
TexthelpSpeechStream.g_strWebServices = "speechstreamtoolbar-webservices.texthelp.com";
TexthelpSpeechStream.g_strBuild = "208";            //*** Set to latest release build version.
TexthelpSpeechStream.g_strCustId = "2990";          //*** Set to customer ID value
TexthelpSpeechStream.g_strLoginName = "commonlit";   //** Set to customer user name
TexthelpSpeechStream.g_strBookId = null;
TexthelpSpeechStream.g_strPageId = null;
TexthelpSpeechStream.g_strVoiceName = "Vocalizer Expressive Ava Premium High 22kHz";
TexthelpSpeechStream.g_bClickToSpeakToggleState = false;

//*** Note that not all customers use book id and page id.
//*** Parameters and lines related to them here and further down can be removed for customers who don't use them.
//*** Also some might want to provide them by other means, so for them remove parameters, set to default and let them call setter functions
TexthelpSpeechStream.addToolbar = function (p_strBookId, p_strPageId)
{
    if(typeof(p_strBookId) == "string")
    {
        TexthelpSpeechStream.g_strBookId = p_strBookId;
    }

    if(typeof(p_strPageId) == "string")
    {
        TexthelpSpeechStream.g_strPageId = p_strPageId;
    }

    if(!TexthelpSpeechStream.g_bAdded)
    {
        var elem = document.createElement("script");
        elem.type = "text/javascript";
        elem.src = "//" + TexthelpSpeechStream.g_strServer + "/SpeechStream/v" + TexthelpSpeechStream.g_strBuild + "/texthelpMain.js";
        document.body.appendChild(elem);
        TexthelpSpeechStream.g_bAdded = true;
    }
};

function $rw_userParameters()
{
    try
    {
        eba_server = TexthelpSpeechStream.g_strServer;
        eba_server_version  = TexthelpSpeechStream.g_strBuild;
        eba_live_servers = [TexthelpSpeechStream.g_strSpeechServer, TexthelpSpeechStream.g_strSpeechServerBackup];
        eba_cache_servers = [TexthelpSpeechStream.g_strCacheServer];
        eba_login_name = TexthelpSpeechStream.g_strLoginName;
        eba_voice = TexthelpSpeechStream.g_strVoiceName;

        eba_language = ENGLISH_US;
        eba_locale = LOCALE_US;         // Differentaiates dictionaries for US & UK
        eba_ignore_buttons = true;
        eba_use_html5 = true;
        eba_ssl_flag = (location.protocol == "https:");

        // Selecting buttons to show
        //eba_icons = main_icons;
        eba_icons = 0;
        eba_no_display_icons =  main_icons;

        //*** Selection for buttons in new UI.  May vary between customers
        eba_ui_buttons = 'play pause stop translate dictionary ' +
                'highlights highlightsCollect ';

//        eba_ui_buttons = 'clicktospeak play pause stop translate factfinder dictionary pictureDictionary highlights highlightsCollect vocab mp3maker stickynotes screenmask settings'


        eba_cust_id = TexthelpSpeechStream.g_strCustId;
        eba_book_id = TexthelpSpeechStream.g_strBookId;
        eba_page_id = TexthelpSpeechStream.g_strPageId;

        //***  Cache options may vary between customers.  This is typical but customers without bookid/pageid cannot use this.
        eba_cache_mode = true;                          // Looks for cached audio on server
        eba_cache_live_generation = true;               // Enables live speech generation if cached audio is not found
        eba_check_pronunciation_before_cache = true;    // Checks pronunciation table before checking cache

        eba_play_start_point = "";          // When play button is clicked and no text is selected, play begins at the top of the page

        dtdType="xtran";

        eba_new_services = true;
        eba_new_services_translate = true;
        eba_new_services_dictionary = true;
        eba_new_services_pict_dictionary = true;
        eba_translate_server = TexthelpSpeechStream.g_strWebServices;
        eba_dictionary_server = TexthelpSpeechStream.g_strWebServices;
        eba_picturedictionary_server = TexthelpSpeechStream.g_strWebServices;
        eba_vocabulary_server = TexthelpSpeechStream.g_strSpeechServer;
		eba_translate_type = "paragraph";

        // for new UI
        eba_speechmode_callback = TexthelpSpeechStream.displayupdate;
        eba_onload_callback = TexthelpSpeechStream.fullToolbarLoadedCallback;


        SpeechStream.data.pageData.strHighlightTag= "thspan";
        SpeechStream.data.pageData.strWrapperTag = "thspan";
    }
    catch(err)
    {
    }
}

TexthelpSpeechStream.displayupdate = function (p_bSpeaking)
{
    try
    {
        if(p_bSpeaking)
        {
            texthelp.SpeechStream.toolbar.disableButtons();
        }
        else
        {
            texthelp.SpeechStream.toolbar.enableButtons();
        }
    }
    catch(e)
    {

    }
};


